import * as THREE from "three";
import { io } from "socket.io-client";

const socket = io({ path: "/api/socket.io" });
const $ = id => document.getElementById(id);
let scene, camera, renderer, clock, player, weapon;
let webglAvailable = true;
let roomState = null, selfId = null, joined = false, playing = false;
let yaw = 0, pitch = 0, health = 200, lastMove = 0, lastShot = 0;
let keys = {}, remoteMeshes = new Map(), zombieMeshes = new Map(), mapGroup;
const raycaster = new THREE.Raycaster();
const worldUp = new THREE.Vector3(0,1,0);
const obstacles = [];
const MAP_NAMES = {warehouse:"INDUSTRIAL WAREHOUSE",city:"ABANDONED CITY",bunker:"UNDERGROUND BUNKER"};

function status(text){ $("status").textContent = text; }
function showNotice(text){ $("notice").textContent=text; setTimeout(()=>{$("notice").textContent="";},2400); }
function name(){return ($("playerName").value.trim() || "Player").slice(0,16);}
function updateObjective(data){
  if(data.kind==="zombies"){
    $("objective").textContent=`SURVIVE WAVE ${data.wave} · TEAM ELIMINATIONS ${data.score}`;
  }else{
    const scores=data.teamScores||[0,0];
    $("objective").textContent=`BLUE ${scores[0]} — ${scores[1]} RED · FIRST TO 5`;
  }
}

document.querySelectorAll("[data-mode]").forEach(btn=>btn.addEventListener("click",()=>queue(btn.dataset.mode)));
$("zombies").onclick=()=>queue("zombies");
function queue(mode){
  if(!socket.connected) return status("Server is not connected yet.");
  $("menu").classList.add("hidden"); $("queueScreen").classList.remove("hidden");
  $("queueText").textContent="Searching for real players. No bots will be added.";
  socket.emit("quickPlay",{mode,name:name()});
}
$("cancelQueue").onclick=()=>{socket.emit("cancelQueue");$("queueScreen").classList.add("hidden");$("menu").classList.remove("hidden");};
$("createPrivate").onclick=()=>{if(!socket.connected)return status("Server is not connected.");socket.emit("createPrivate",{name:name()});};
$("joinPrivate").onclick=()=>{socket.emit("joinPrivate",{code:$("roomCode").value,name:name()});};
$("leaveMatch").onclick=leaveMatch;
function leaveMatch(){
  location.reload();
}
socket.on("connect",()=>status(webglAvailable
  ? "Connected to multiplayer server."
  : "Multiplayer connected; 3D gameplay requires WebGL support."));
socket.on("disconnect",()=>{status("Disconnected from server.");showNotice("Connection lost");});
socket.on("notice",status);
socket.on("queue",q=>{$("queueText").textContent=`${q.count} / ${q.needed} players found. Waiting for real players...`;});
socket.on("queueCancelled",()=>{});
socket.on("privateCreated",d=>{status("Private room code: "+d.code);});
socket.on("joined",data=>{
  roomState=data; selfId=data.selfId; joined=true;
  $("queueScreen").classList.add("hidden"); $("menu").classList.add("hidden");
  $("hud").classList.remove("hidden"); $("startOverlay").classList.remove("hidden");
  $("matchTitle").textContent=data.kind==="zombies"?"ZOMBIE CO-OP READY":`${data.mode} MATCH READY`;
  $("modeLabel").textContent=data.mode.toUpperCase();
  $("mapLabel").textContent=(MAP_NAMES[data.map]||data.map);
  updateObjective(data);
  buildWorld(data.map); syncPlayers(data.players); syncZombies(data.zombies||[]);
});
socket.on("state",data=>{
  roomState=data;
  if(!joined)return;
  $("mapLabel").textContent=MAP_NAMES[data.map]||data.map;
  updateObjective(data);
  syncPlayers(data.players);syncZombies(data.zombies||[]);
});
socket.on("playerMoved",p=>updateRemote(p));
socket.on("roundEnded",data=>{
  roomState={...roomState,teamScores:data.teamScores,roundNumber:data.roundNumber,roundOver:true,matchOver:data.matchOver};
  playing=false;
  document.exitPointerLock?.();
  const winner=data.winnerTeam===0?"BLUE":"RED";
  const score=`${data.teamScores[0]} — ${data.teamScores[1]}`;
  $("objective").textContent=data.matchOver
    ? `${winner} WINS MATCH · ${score}`
    : `${winner} WINS ROUND · ${score}`;
  $("matchTitle").textContent=data.matchOver
    ? `${winner} TEAM WINS THE MATCH`
    : `${winner} TEAM WINS ROUND ${data.roundNumber}`;
  $("enterGame").textContent=data.matchOver?"RETURN TO LOBBY":"NEXT ROUND STARTING...";
  $("enterGame").disabled=!data.matchOver;
  $("startOverlay").classList.remove("hidden");
});
socket.on("roundStarted",data=>{
  roomState=data;
  playing=false;
  updateObjective(data);
  syncPlayers(data.players);
  syncZombies(data.zombies||[]);
  $("matchTitle").textContent=`ROUND ${data.roundNumber}`;
  $("enterGame").textContent="ENTER ROUND";
  $("enterGame").disabled=false;
  $("startOverlay").classList.remove("hidden");
});
socket.on("hit",d=>{
  if(d.targetId!==selfId)return;
  health=d.health;
  $("health").textContent=health;
  if(health===0&&roomState?.kind==="pvp"){
    playing=false;
    document.exitPointerLock?.();
    $("matchTitle").textContent="ELIMINATED";
    $("enterGame").textContent="WAIT FOR ROUND END";
    $("enterGame").disabled=true;
    $("startOverlay").classList.remove("hidden");
  }
});

function initThree(){
  scene=new THREE.Scene();scene.background=new THREE.Color(0x91a8b5);scene.fog=new THREE.Fog(0x91a8b5,35,85);
  camera=new THREE.PerspectiveCamera(76,innerWidth/innerHeight,.1,120);
  try {
    renderer=new THREE.WebGLRenderer({antialias:true});
  } catch {
    webglAvailable = false;
    status("Multiplayer connected; 3D gameplay requires WebGL support.");
    document.querySelectorAll(".mode-grid button, #zombies, #createPrivate, #joinPrivate")
      .forEach(button => { button.disabled = true; });
    return;
  }
  renderer.setPixelRatio(Math.min(devicePixelRatio,1.7));renderer.setSize(innerWidth,innerHeight);renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;document.body.appendChild(renderer.domElement);
  scene.add(new THREE.HemisphereLight(0xd9edff,0x52606a,2.0));
  const sun=new THREE.DirectionalLight(0xffffff,2.2);sun.position.set(15,30,10);sun.castShadow=true;scene.add(sun);
  clock=new THREE.Clock();
  player=new THREE.Object3D();player.position.set(0,1,8);scene.add(player);player.add(camera);camera.position.set(0,0.65,0);
  makeWeapon();
  window.addEventListener("resize",()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight);});
  document.addEventListener("keydown",e=>{keys[e.code]=true;});
  document.addEventListener("keyup",e=>{keys[e.code]=false;});
  document.addEventListener("mousemove",e=>{if(document.pointerLockElement===renderer.domElement){yaw-=e.movementX*.0022;pitch-=e.movementY*.0022;pitch=Math.max(-1.35,Math.min(1.35,pitch));camera.rotation.set(pitch,yaw,0,"YXZ");}});
  renderer.domElement.addEventListener("click",()=>{if(playing)renderer.domElement.requestPointerLock();});
  document.addEventListener("mousedown",e=>{if(e.button===0&&playing&&document.pointerLockElement===renderer.domElement)shoot();});
  $("enterGame").onclick=()=>{
    if(roomState?.matchOver){leaveMatch();return;}
    if(roomState?.roundOver||health<=0)return;
    playing=true;
    $("startOverlay").classList.add("hidden");
    renderer.domElement.requestPointerLock();
  };
  animate();
}
function mat(color,roughness=1){return new THREE.MeshStandardMaterial({color,roughness,flatShading:true});}
function box(parent,x,y,z,sx,sy,sz,color,collide=true){
  const m=new THREE.Mesh(new THREE.BoxGeometry(sx,sy,sz),mat(color));m.position.set(x,y,z);m.castShadow=true;m.receiveShadow=true;parent.add(m);
  if(collide)obstacles.push({x,z,hx:sx/2,hz:sz/2});return m;
}
function floor(parent,color=0x66716c,size=80){const m=new THREE.Mesh(new THREE.PlaneGeometry(size,size),mat(color));m.rotation.x=-Math.PI/2;m.position.y=0; m.receiveShadow=true;parent.add(m);}
function buildWorld(map){
  if(mapGroup)scene.remove(mapGroup);mapGroup=new THREE.Group();scene.add(mapGroup);obstacles.length=0;
  const ground=map==="city"?0x777b76:map==="bunker"?0x454c52:0x69746e;floor(mapGroup,ground,80);
  // Arena boundary walls
  box(mapGroup,0,2,-35,70,4,1,0x38434a);box(mapGroup,0,2,35,70,4,1,0x38434a);
  box(mapGroup,-35,2,0,1,4,70,0x38434a);box(mapGroup,35,2,0,1,4,70,0x38434a);
  if(map==="warehouse"){
    for(let x=-22;x<=22;x+=11){box(mapGroup,x,1.4,-13,5,2.8,4,0x9a7447);box(mapGroup,x,1.4,13,5,2.8,4,0x9a7447);}
    for(let z=-8;z<=8;z+=8){box(mapGroup,-12,2,z,2,4,2,0x65727b);box(mapGroup,12,2,z,2,4,2,0x65727b);}
    box(mapGroup,0,1.4,0,8,2.8,3,0xb28a50);
    for(let x=-25;x<=25;x+=10)box(mapGroup,x,3,-29,1,6,1,0xd29b4e,false);
  }else if(map==="city"){
    for(let x=-24;x<=24;x+=12){box(mapGroup,x,3,-23,8,6,8,0x77716a);box(mapGroup,x,3,23,8,6,8,0x686d70);}
    for(let z=-12;z<=12;z+=12){box(mapGroup,-17,.8,z,4,1.6,2.5,0x46545c);box(mapGroup,17,.8,z,4,1.6,2.5,0x46545c);}
    box(mapGroup,0,1,0,5,2,5,0x8a8172);
    for(let i=0;i<5;i++)box(mapGroup,-27+i*13,.6,-5,3,1.2,1.5,0x52616a);
  }else{
    for(let z=-24;z<=24;z+=12){box(mapGroup,-10,2,z,2,4,8,0x626d76);box(mapGroup,10,2,z,2,4,8,0x626d76);}
    box(mapGroup,0,2,-17,12,4,2,0x626d76);box(mapGroup,0,2,17,12,4,2,0x626d76);
    box(mapGroup,0,1.2,0,6,2.4,6,0x777f82);
    for(let x=-26;x<=26;x+=13){box(mapGroup,x,2,-29,1,4,1,0x9c744d,false);box(mapGroup,x,2,29,1,4,1,0x9c744d,false);}
  }
  // low-poly decorative lights
  for(let i=0;i<12;i++){const p=new THREE.Mesh(new THREE.BoxGeometry(.5,.5,.5),mat(0xd6bd72));p.position.set((Math.random()-.5)*50,4,(Math.random()-.5)*50);mapGroup.add(p);}
}
function makeCharacter(color){
  const g=new THREE.Group();
  const body=new THREE.Mesh(new THREE.CylinderGeometry(.38,.48,1.1,6),mat(color));body.position.y=0;body.castShadow=true;g.add(body);
  const head=new THREE.Mesh(new THREE.IcosahedronGeometry(.32,0),mat(0xe0b99a));head.position.y=.82;head.castShadow=true;g.add(head);
  const legs=new THREE.Mesh(new THREE.BoxGeometry(.55,.55,.35),mat(0x303d4a));legs.position.y=-.72;g.add(legs);
  return g;
}
function makeWeapon(){
  weapon=new THREE.Group();
  const dark=mat(0x202a32),metal=mat(0x65737b);
  const body=new THREE.Mesh(new THREE.BoxGeometry(.18,.16,.65),dark);body.position.set(.28,-.25,-.55);weapon.add(body);
  const barrel=new THREE.Mesh(new THREE.CylinderGeometry(.045,.045,.55,6),metal);barrel.rotation.x=Math.PI/2;barrel.position.set(.28,-.22,-.95);weapon.add(barrel);
  const grip=new THREE.Mesh(new THREE.BoxGeometry(.12,.25,.15),dark);grip.position.set(.28,-.42,-.38);weapon.add(grip);
  camera.add(weapon);
}
function syncPlayers(players){
  const seen=new Set();
  for(const p of players){
    if(p.id===selfId){
      health=p.health;
      $("health").textContent=health;
      if(player)player.position.set(p.x,p.y,p.z);
      yaw=p.yaw;
      pitch=p.pitch;
      if(camera)camera.rotation.set(pitch,yaw,0,"YXZ");
      continue;
    }
    seen.add(p.id);
    updateRemote(p);
  }
  for(const [id,m] of remoteMeshes){if(!seen.has(id)){scene.remove(m);remoteMeshes.delete(id);}}
}
function updateRemote(p){
  if(p.id===selfId)return;
  let m=remoteMeshes.get(p.id);if(!m){m=makeCharacter(p.team===0?0x4b91d0:0xd45e51);scene.add(m);remoteMeshes.set(p.id,m);}
  const eliminated=p.health<=0;
  if(m.userData.eliminated!==eliminated){
    m.userData.eliminated=eliminated;
    m.traverse(child=>{
      if(!child.isMesh)return;
      const materials=Array.isArray(child.material)?child.material:[child.material];
      for(const material of materials){
        material.transparent=eliminated;
        material.opacity=eliminated?0.35:1;
        material.depthWrite=!eliminated;
        material.needsUpdate=true;
      }
    });
  }
  m.position.set(p.x,1,p.z);m.rotation.y=p.yaw||0;m.visible=true;
}
function syncZombies(zombies){
  const seen=new Set();
  for(const z of zombies){seen.add(z.id);let m=zombieMeshes.get(z.id);if(!m){m=makeCharacter(0x67a64f);scene.add(m);zombieMeshes.set(z.id,m);}m.position.set(z.x,1,z.z);}
  for(const [id,m] of zombieMeshes){if(!seen.has(id)){scene.remove(m);zombieMeshes.delete(id);}}
}
function blocked(x,z){
  for(const o of obstacles){if(Math.abs(x-o.x)<o.hx+.55&&Math.abs(z-o.z)<o.hz+.55)return true;}return false;
}
function shoot(){
  const now=performance.now();if(now-lastShot<180)return;lastShot=now;
  const dir=new THREE.Vector3();camera.getWorldDirection(dir);
  const origin=camera.getWorldPosition(new THREE.Vector3());
  socket.emit("shoot",{origin:{x:player.position.x,y:origin.y,z:player.position.z},direction:{x:dir.x,y:dir.y,z:dir.z}});
  weapon.position.z=.06;setTimeout(()=>{if(weapon)weapon.position.z=0;},65);
}
function animate(){
  requestAnimationFrame(animate);if(!renderer)return;
  const dt=Math.min(clock.getDelta(),.05);
  if(playing&&player){
    const forward=new THREE.Vector3(-Math.sin(yaw),0,-Math.cos(yaw));
    const right=new THREE.Vector3(Math.cos(yaw),0,-Math.sin(yaw));
    let move=new THREE.Vector3();
    if(keys.KeyW)move.add(forward);if(keys.KeyS)move.sub(forward);if(keys.KeyD)move.add(right);if(keys.KeyA)move.sub(right);
    if(move.lengthSq()>0){move.normalize().multiplyScalar((keys.ShiftLeft?9:6)*dt);const nx=player.position.x+move.x,nz=player.position.z+move.z;if(!blocked(nx,player.position.z))player.position.x=nx;if(!blocked(player.position.x,nz))player.position.z=nz;}
    const now=performance.now();if(now-lastMove>55){lastMove=now;socket.emit("move",{x:player.position.x,y:1,z:player.position.z,yaw,pitch});}
    if(keys.Space){keys.Space=false;showNotice("Jump animation is coming in the next build.");}
  }
  renderer.render(scene,camera);
}
initThree();
