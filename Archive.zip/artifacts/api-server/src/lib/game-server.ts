import { randomBytes } from "node:crypto";
import type { Server as HttpServer } from "node:http";
import { Server, type Socket } from "socket.io";

const SOCKET_PATH = "/api/socket.io";

const MODES = {
  "1v1": { size: 2, kind: "pvp" },
  "2v2": { size: 4, kind: "pvp" },
  "3v3": { size: 6, kind: "pvp" },
  "4v4": { size: 8, kind: "pvp" },
  "5v5": { size: 10, kind: "pvp" },
  zombies: { size: 10, kind: "zombies" },
  private10v10: { size: 20, kind: "pvp" },
} as const;

type GameMode = keyof typeof MODES;
type RoomKind = "pvp" | "zombies";
type TeamId = 0 | 1;

interface Player {
  id: string;
  name: string;
  x: number;
  y: number;
  z: number;
  yaw: number;
  pitch: number;
  health: number;
  team: TeamId;
  lastShot: number;
}

interface Zombie {
  id: string;
  x: number;
  y: number;
  z: number;
  health: number;
  maxHealth: number;
}

interface Room {
  id: string;
  code: string | null;
  mode: GameMode;
  kind: RoomKind;
  map: string;
  players: Map<string, Player>;
  maxPlayers: number;
  zombies: Zombie[];
  wave: number;
  score: number;
  teamScores: [number, number];
  roundNumber: number;
  roundOver: boolean;
  matchOver: boolean;
  isPrivate: boolean;
}

interface PublicPlayer extends Omit<Player, "lastShot"> {}

interface PublicRoom {
  id: string;
  code: string | null;
  mode: GameMode;
  map: string;
  kind: RoomKind;
  players: PublicPlayer[];
  zombies: Zombie[];
  wave: number;
  score: number;
  teamScores: [number, number];
  roundNumber: number;
  roundOver: boolean;
  matchOver: boolean;
}

interface MoveData {
  x: number;
  z: number;
  yaw: number;
  pitch: number;
}

interface Vector3 {
  x: number;
  y: number;
  z: number;
}

interface ClientToServerEvents {
  quickPlay: (payload: { mode: string; name?: string }) => void;
  cancelQueue: () => void;
  createPrivate: (payload: { name?: string }) => void;
  joinPrivate: (payload: { code?: string; name?: string }) => void;
  move: (data: MoveData) => void;
  shoot: (data: { origin: Vector3; direction: Vector3 }) => void;
}

interface ServerToClientEvents {
  joined: (room: PublicRoom & { selfId: string }) => void;
  state: (room: PublicRoom) => void;
  queue: (data: { mode: GameMode; count: number; needed: number }) => void;
  queueCancelled: () => void;
  privateCreated: (data: { code: string }) => void;
  notice: (message: string) => void;
  playerMoved: (player: PublicPlayer) => void;
  hit: (data: { targetId: string; health: number; shooterId: string }) => void;
  roundEnded: (data: {
    winnerTeam: TeamId;
    teamScores: [number, number];
    roundNumber: number;
    matchOver: boolean;
  }) => void;
  roundStarted: (room: PublicRoom) => void;
}

interface QueueEntry {
  socketId: string;
  name: string;
}

type GameSocket = Socket<ClientToServerEvents, ServerToClientEvents>;

const MAPS = ["warehouse", "city", "bunker"];

function makeCode(): string {
  return randomBytes(3).toString("hex").toUpperCase();
}

function randomSpawn(team: TeamId): { x: number; y: number; z: number } {
  const side = team === 0 ? -1 : 1;
  return {
    x: side * (4 + Math.random() * 3),
    y: 1,
    z: (Math.random() - 0.5) * 12,
  };
}

function publicRoom(room: Room): PublicRoom {
  return {
    id: room.id,
    code: room.code,
    mode: room.mode,
    map: room.map,
    kind: room.kind,
    players: [...room.players.values()].map(
      ({ lastShot: _lastShot, ...player }) => player,
    ),
    zombies: room.zombies,
    wave: room.wave,
    score: room.score,
    teamScores: [...room.teamScores],
    roundNumber: room.roundNumber,
    roundOver: room.roundOver,
    matchOver: room.matchOver,
  };
}

export function attachGameServer(httpServer: HttpServer): void {
  const io = new Server<ClientToServerEvents, ServerToClientEvents>(httpServer, {
    path: SOCKET_PATH,
  });
  const rooms = new Map<string, Room>();
  const queues = new Map<GameMode, QueueEntry[]>();
  const playerRoom = new Map<string, string>();

  function leaveRoom(socketId: string): void {
    const roomId = playerRoom.get(socketId);
    if (!roomId) return;

    const room = rooms.get(roomId);
    playerRoom.delete(socketId);
    if (!room) return;

    room.players.delete(socketId);
    io.sockets.sockets.get(socketId)?.leave(roomId);
    if (room.players.size === 0) {
      rooms.delete(roomId);
    } else {
      io.to(roomId).emit("state", publicRoom(room));
    }
  }

  function spawnWave(room: Room): void {
    const count = Math.min(5 + room.wave * 2, 24);
    room.zombies = Array.from({ length: count }, (_, index) => ({
      id: `z${room.wave}_${index}`,
      x: (Math.random() - 0.5) * 25,
      y: 0.9,
      z: (Math.random() - 0.5) * 25,
      health: 50 + room.wave * 10,
      maxHealth: 50 + room.wave * 10,
    }));
  }

  function makeRoom(mode: GameMode, isPrivate = false): Room {
    const config = MODES[mode];
    const room: Room = {
      id: makeCode() + makeCode(),
      code: isPrivate ? makeCode() : null,
      mode,
      kind: config.kind,
      map: MAPS[Math.floor(Math.random() * MAPS.length)]!,
      players: new Map(),
      maxPlayers: config.size,
      zombies: [],
      wave: 1,
      score: 0,
      teamScores: [0, 0],
      roundNumber: 1,
      roundOver: false,
      matchOver: false,
      isPrivate,
    };
    rooms.set(room.id, room);
    if (room.kind === "zombies") spawnWave(room);
    return room;
  }

  function addPlayer(
    socket: GameSocket,
    room: Room,
    name: string | undefined,
  ): void {
    const team: TeamId = room.kind === "zombies" ? 0 : (room.players.size % 2) as TeamId;
    const spawn = randomSpawn(team);
    const player: Player = {
      id: socket.id,
      name: String(name || "Player").slice(0, 16),
      ...spawn,
      yaw: team === 0 ? Math.PI / 2 : -Math.PI / 2,
      pitch: 0,
      health: 200,
      team,
      lastShot: 0,
    };
    room.players.set(socket.id, player);
    playerRoom.set(socket.id, room.id);
    socket.join(room.id);
    socket.emit("joined", { ...publicRoom(room), selfId: socket.id });
    io.to(room.id).emit("state", publicRoom(room));
  }

  function endRound(room: Room, losingTeam: TeamId): void {
    if (room.roundOver || room.matchOver) return;

    const winnerTeam: TeamId = losingTeam === 0 ? 1 : 0;
    if (winnerTeam === 0) {
      room.teamScores[0] += 1;
    } else {
      room.teamScores[1] += 1;
    }
    room.roundOver = true;
    room.matchOver = room.teamScores[winnerTeam] >= 5;

    io.to(room.id).emit("roundEnded", {
      winnerTeam,
      teamScores: [...room.teamScores],
      roundNumber: room.roundNumber,
      matchOver: room.matchOver,
    });

    if (room.matchOver) return;

    setTimeout(() => {
      if (rooms.get(room.id) !== room || room.matchOver) return;

      room.roundNumber += 1;
      room.roundOver = false;
      for (const player of room.players.values()) {
        const spawn = randomSpawn(player.team);
        player.x = spawn.x;
        player.y = spawn.y;
        player.z = spawn.z;
        player.yaw = player.team === 0 ? Math.PI / 2 : -Math.PI / 2;
        player.pitch = 0;
        player.health = 200;
        player.lastShot = 0;
      }

      io.to(room.id).emit("roundStarted", publicRoom(room));
    }, 3000);
  }

  function matchQueue(
    socket: GameSocket,
    modeName: string,
    name: string | undefined,
  ): void {
    if (!(modeName in MODES) || modeName === "private10v10") {
      socket.emit("notice", "That matchmaking mode is unavailable.");
      return;
    }

    const mode = modeName as GameMode;
    leaveRoom(socket.id);
    for (const [queuedMode, queue] of queues) {
      queues.set(
        queuedMode,
        queue.filter((entry) => entry.socketId !== socket.id),
      );
    }

    if (mode === "zombies") {
      const room =
        [...rooms.values()].find(
          (candidate) =>
            candidate.kind === "zombies" &&
            !candidate.isPrivate &&
            candidate.players.size < candidate.maxPlayers,
        ) ?? makeRoom("zombies");
      addPlayer(socket, room, name);
      return;
    }

    const queue = queues.get(mode) ?? [];
    queue.push({ socketId: socket.id, name: String(name || "Player").slice(0, 16) });
    queues.set(mode, queue);

    socket.emit("queue", {
      mode,
      count: queue.length,
      needed: MODES[mode].size,
    });

    const needed = MODES[mode].size;
    if (queue.length >= needed) {
      const group = queue.splice(0, needed);
      const room = makeRoom(mode);
      for (const entry of group) {
        const queuedSocket = io.sockets.sockets.get(entry.socketId);
        if (queuedSocket) addPlayer(queuedSocket, room, entry.name);
      }
    }
  }

  io.on("connection", (socket) => {
    socket.on("quickPlay", ({ mode, name }) => matchQueue(socket, mode, name));

    socket.on("cancelQueue", () => {
      for (const [mode, queue] of queues) {
        queues.set(
          mode,
          queue.filter((entry) => entry.socketId !== socket.id),
        );
      }
      socket.emit("queueCancelled");
    });

    socket.on("createPrivate", ({ name }) => {
      leaveRoom(socket.id);
      const room = makeRoom("private10v10", true);
      addPlayer(socket, room, name);
      socket.emit("privateCreated", { code: room.code! });
    });

    socket.on("joinPrivate", ({ code, name }) => {
      const normalizedCode = String(code || "").toUpperCase();
      const room = [...rooms.values()].find(
        (candidate) => candidate.isPrivate && candidate.code === normalizedCode,
      );
      if (!room) {
        socket.emit("notice", "Room code not found.");
        return;
      }
      if (room.players.size >= room.maxPlayers) {
        socket.emit("notice", "That room is full.");
        return;
      }
      leaveRoom(socket.id);
      addPlayer(socket, room, name);
    });

    socket.on("move", (data) => {
      const room = rooms.get(playerRoom.get(socket.id) ?? "");
      const player = room?.players.get(socket.id);
      if (
        !room ||
        !player ||
        room.roundOver ||
        room.matchOver ||
        player.health <= 0 ||
        !data ||
        !Number.isFinite(data.x) ||
        !Number.isFinite(data.z) ||
        !Number.isFinite(data.yaw) ||
        !Number.isFinite(data.pitch)
      ) {
        return;
      }

      const dx = data.x - player.x;
      const dz = data.z - player.z;
      if (Math.hypot(dx, dz) > 2.2) return;

      player.x = Math.max(-34, Math.min(34, data.x));
      player.z = Math.max(-34, Math.min(34, data.z));
      player.yaw = data.yaw;
      player.pitch = Math.max(-1.4, Math.min(1.4, data.pitch));
      const { lastShot: _lastShot, ...publicPlayer } = player;
      socket.to(room.id).emit("playerMoved", publicPlayer);
    });

    socket.on("shoot", ({ origin, direction }) => {
      const room = rooms.get(playerRoom.get(socket.id) ?? "");
      const shooter = room?.players.get(socket.id);
      if (
        !room ||
        !shooter ||
        room.roundOver ||
        room.matchOver ||
        shooter.health <= 0 ||
        !origin ||
        !direction ||
        ![origin.x, origin.y, origin.z, direction.x, direction.y, direction.z].every(
          Number.isFinite,
        )
      ) {
        return;
      }

      const now = Date.now();
      if (now - shooter.lastShot < 180) return;
      shooter.lastShot = now;

      const { x: ox, z: oz } = origin;
      const { x: dx, z: dz } = direction;
      if (Math.hypot(ox - shooter.x, oz - shooter.z) > 3) return;

      let bestPlayer: Player | null = null;
      let bestPlayerDistance = 28;
      if (room.kind === "pvp") {
        for (const target of room.players.values()) {
          if (
            target.id === shooter.id ||
            target.team === shooter.team ||
            target.health <= 0
          ) {
            continue;
          }
          const vx = target.x - ox;
          const vz = target.z - oz;
          const distance = vx * dx + vz * dz;
          if (distance < 0 || distance > bestPlayerDistance) continue;
          if (Math.abs(vx * dz - vz * dx) < 0.85) {
            bestPlayer = target;
            bestPlayerDistance = distance;
          }
        }

        if (bestPlayer) {
          bestPlayer.health = Math.max(0, bestPlayer.health - 25);
          io.to(room.id).emit("hit", {
            targetId: bestPlayer.id,
            health: bestPlayer.health,
            shooterId: socket.id,
          });
          io.to(room.id).emit("state", publicRoom(room));
          if (bestPlayer.health === 0) {
            const losingTeam = bestPlayer.team;
            const teamStillAlive = [...room.players.values()].some(
              (player) => player.team === losingTeam && player.health > 0,
            );
            if (!teamStillAlive) endRound(room, losingTeam);
          }
        }
        return;
      }

      let bestZombie: Zombie | null = null;
      let bestZombieDistance = 28;
      for (const zombie of room.zombies) {
        const vx = zombie.x - ox;
        const vz = zombie.z - oz;
        const distance = vx * dx + vz * dz;
        if (distance < 0 || distance > bestZombieDistance) continue;
        if (Math.abs(vx * dz - vz * dx) < 1.0) {
          bestZombie = zombie;
          bestZombieDistance = distance;
        }
      }

      if (bestZombie) {
        bestZombie.health -= 25;
        if (bestZombie.health <= 0) {
          room.zombies = room.zombies.filter(
            (zombie) => zombie.id !== bestZombie!.id,
          );
          room.score++;
          if (room.zombies.length === 0) {
            room.wave++;
            spawnWave(room);
          }
        }
        io.to(room.id).emit("state", publicRoom(room));
      }
    });

    socket.on("disconnect", () => {
      leaveRoom(socket.id);
      for (const [mode, queue] of queues) {
        queues.set(
          mode,
          queue.filter((entry) => entry.socketId !== socket.id),
        );
      }
    });
  });

  const zombieLoop = setInterval(() => {
    for (const room of rooms.values()) {
      if (room.kind !== "zombies" || room.players.size === 0) continue;
      for (const zombie of room.zombies) {
        const alivePlayers = [...room.players.values()].filter(
          (player) => player.health > 0,
        );
        if (alivePlayers.length === 0) continue;
        alivePlayers.sort(
          (a, b) =>
            Math.hypot(a.x - zombie.x, a.z - zombie.z) -
            Math.hypot(b.x - zombie.x, b.z - zombie.z),
        );
        const target = alivePlayers[0]!;
        const dx = target.x - zombie.x;
        const dz = target.z - zombie.z;
        const distance = Math.hypot(dx, dz) || 1;
        if (distance > 1.25) {
          zombie.x += (dx / distance) * 0.055;
          zombie.z += (dz / distance) * 0.055;
        } else {
          target.health = Math.max(0, target.health - 1);
        }
      }
      io.to(room.id).emit("state", publicRoom(room));
    }
  }, 100);

  httpServer.on("close", () => {
    clearInterval(zombieLoop);
    void io.close();
  });
}
