import { createServer } from "node:http";
import app from "./app";
import { logger } from "./lib/logger";
import { attachGameServer } from "./lib/game-server";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

const server = createServer(app);
attachGameServer(server);
server.listen(port, () => {
  logger.info({ port }, "Server listening");
});
